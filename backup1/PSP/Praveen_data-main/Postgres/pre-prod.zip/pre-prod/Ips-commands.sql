
--us-west(Primary cluster) Ips deployment steps:

eiamCli aws_creds -a 152430470825 -r PowerUser -p default


--Pre-prerequisites for all clusters config file and deployment commands

cdk list --all -c env=ppd -c config=ppsp-prerequisites-ppd-us-west.json
cdk diff  --all -c env=ppd -c config=ppsp-prerequisites-ppd-us-west.json
cdk deploy  --all -c env=ppd -c config=ppsp-prerequisites-ppd-us-west.json


--cluster wise config files and deployment commands

1.ppsp-pds-db(Global database).

cdk list  --all -c env=pds -c group=primary-pds -c config=ppsp-pds-db.json
cdk diff  --all -c env=pds -c group=primary-pds -c config=ppsp-pds-db.json
cdk deploy  --all -c env=pds -c group=primary-pds -c config=ppsp-pds-db.json

2.spsp-sys-db(single cluster)

cdk list  --all -c env=sys -c group=primary-sys -c config=spsp-sys-db.json
cdk diff  --all -c env=sys -c group=primary-sys -c config=spsp-sys-db.json
cdk deploy  --all -c env=sys -c group=primary-sys -c config=spsp-sys-db.json

3.ppsp-pds-mon (single cluster)

cdk list  --all -c env=pds -c group=primary-pds-mon -c config=ppsp-pds-mon.json
cdk diff  --all -c env=pds -c group=primary-pds-mon -c config=ppsp-pds-mon.json
cdk deploy  --all -c env=pds -c group=primary-pds-mon -c config=ppsp-pds-mon.json

4.psp-shared-aud(single cluster)

cdk list  --all -c env=shared -c group=primary-shared-aud -c config=psp-shared-aud.json
cdk diff  --all -c env=shared -c group=primary-shared-aud -c config=psp-shared-aud.json
cdk deploy  --all -c env=shared -c group=primary-shared-aud -c config=psp-shared-aud.json

5.pspmock-dev-mock(single cluster)

cdk list  --all -c env=dev -c group=primary-mockclient -c config=pspmock-dev-mock.json
cdk diff  --all -c env=dev -c group=primary-mockclient -c config=pspmock-dev-mock.json
cdk deploy  --all -c env=dev -c group=primary-mockclient -c config=pspmock-dev-mock.json

3.ppsp-pds-mon (single cluster)

cdk list  --all -c env=sys -c group=primary-sys-mon -c config=ppsp-sys-mon.json
cdk diff  --all -c env=sys -c group=primary-sys-mon -c config=ppsp-sys-mon.json
cdk deploy  --all -c env=sys -c group=primary-sys-mon -c config=ppsp-sys-mon.json



cdk list  --all -c env=pds -c group=primary-ppd-arc -c config=ppsp-ppd-arc.json
cdk diff  --all -c env=pds -c group=primary-pds-arc -c config=ppsp-ppd-arc.json
cdk deploy  --all -c env=pds -c group=primary-pds-arc -c config=ppsp-ppd-arc.json


cdk list  --all -c env=pds -c group=primary-ppd-temp -c config=ppsp-ppd-temp.json
cdk diff  --all -c env=ppd -c group=primary-ppd-temp -c config=ppsp-ppd-temp.json
cdk deploy  --all -c env=pds -c group=primary-ppd-temp -c config=ppsp-ppd-arc.json


cdk list  --all -c env=pds -c group=primary-pds-uw02 -c config=ppsp-pds-uw02.json
cdk diff  --all -c env=pds -c group=primary-pds-uw02 -c config=ppsp-pds-uw02.json
cdk deploy  --all -c env=pds -c group=primary-pds-uw02 -c config=ppsp-pds-uw02.json


cdk diff  --all -c env=pds -c group=primary-pds-uw02 -c config=ppsp-pds-uw02-global.json
cdk diff  --all -c env=pds -c group=dr-pds-uw02 -c config=ppsp-pds-uw02-global.json
--Us-east(DR clusters)

--Pre-prerequisites for all clusters config file and deployment commands

cdk list --all -c env=ppd-east -c config=ppsp-prerequisites-ppd-us-east.json
cdk diff --all -c env=ppd-east -c config=ppsp-prerequisites-ppd-us-east.json
cdk deploy --all -c env=ppd-east -c config=ppsp-prerequisites-ppd-us-east.json


1.ppsp-pds-dbdr(Global database).

cdk list  --all -c env=pds -c group=dr-pds -c config=ppsp-pds-db.json
cdk diff  --all -c env=pds -c group=dr-pds -c config=ppsp-pds-db.json
cdk deploy  --all -c env=pds -c group=dr-pds -c config=ppsp-pds-db.json

cdk diff  --all -c env=pds -c group=primary-pds-uw02 -c config=ppsp-pds-uw02-global.json
cdk diff  --all -c env=pds -c group=dr-pds-uw02 -c config=ppsp-pds-uw02-global.json

cdk bootstrap aws://152430470825/us-west-2

