export PGPASSWORD=`cat .pp`
psql_cmd="psql --username=ops_user -h ${1}.cjls0bohfgpq.us-west-2.rds.amazonaws.com -p 5432 ${2} --echo-all -P pager=off -f $3 $4"
eval "$psql_cmd"
