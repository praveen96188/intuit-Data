SELECT count(*) from pg_stat_activity where state = 'active' and pid != pg_backend_pid();

