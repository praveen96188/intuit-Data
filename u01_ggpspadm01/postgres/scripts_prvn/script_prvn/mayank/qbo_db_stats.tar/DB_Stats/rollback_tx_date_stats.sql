PROMPT "=== Rolling back tx_date high low values ==="

exec DBMS_STATS.SET_TABLE_PREFS ('QBO_DATA', 'TXHEADERS_1', 'METHOD_OPT', 'for all columns size auto for columns size 10 invoice_id');
exec DBMS_STATS.SET_TABLE_PREFS ('QBO_DATA', 'TXDETAILS_1', 'METHOD_OPT', 'for all columns size auto for columns size 10 invoice_id deposit_id');


exec DBMS_STATS.GATHER_TABLE_STATS (ownname => 'QBO_DATA' , tabname => 'TXHEADERS_1',cascade => true, estimate_percent => 10, granularity => 'GLOBAL', degree => 2);
exec DBMS_STATS.GATHER_TABLE_STATS (ownname => 'QBO_DATA' , tabname => 'TXDETAILS_1',cascade => true, estimate_percent => 10, granularity => 'GLOBAL', degree => 2);


alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss';

prompt === After rollback ===

break on table_name dup skip 1

select c.table_name, c.column_name, c.data_type, c.num_distinct,  c.num_nulls, round(c.num_nulls/t.num_rows,2)*100 as pct_null, c.density, c.sample_size, c.last_analyzed, c.histogram, c.num_buckets,
decode(data_type,
                'VARCHAR2',to_char(raw_to_varchar2(low_value)),
                'DATE',to_char(raw_to_date(low_value), 'yyyy-mm-dd'),
                'NUMBER',to_char(raw_to_num(low_value))
        ) low_value,
        decode(data_type,
                'VARCHAR2',to_char(raw_to_varchar2(high_value)),
                'DATE',to_char(raw_to_date(high_value), 'yyyy-mm-dd'),
                'NUMBER',to_char(raw_to_num(high_value))
        ) high_value
from dba_tab_columns c, dba_tables t
where c.owner = t.owner
  and c.table_name = t.table_name
  and c.owner = 'QBO_DATA'
  and t.table_name IN ( 'TXHEADERS_1', 'TXDETAILS_1')
  and c.column_name IN ('COMPANY_ID', 'TX_DATE', 'INVOICE_ID', 'DEPOSIT_ID')
order by c.table_name desc, c.column_id;

select table_name, dbms_stats.get_prefs(ownname=>'QBO_DATA',tabname=>t.table_name,pname=>'METHOD_OPT') method_opt_pref
from dba_tables t
where t.owner = 'QBO_DATA'
and t.table_name IN ( 'TXHEADERS_1', 'TXDETAILS_1');

