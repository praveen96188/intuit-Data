

prompt === Before fixing stats ===
@show_tx_col_stats


set serveroutput on timing on 

prompt === Unlocking table stats ===

exec DBMS_STATS.UNLOCK_TABLE_STATS('QBO_DATA', 'TXHEADERS_1');
exec DBMS_STATS.UNLOCK_TABLE_STATS('QBO_DATA', 'TXDETAILS_1');

prompt === Setting table prefs ===

exec QBO_STATS_PKG.SET_TXHEADERS_PREF;
exec QBO_STATS_PKG.SET_TXDETAILS_PREF;

prompt === Fixing stats for last_modify_date ====

exec QBO_STATS_PKG.SET_DATE_RANGE('QBO_DATA', 'TXHEADERS_1', 'LAST_MODIFY_DATE', to_date('2014-01-01', 'yyyy-mm-dd'), trunc(sysdate+30));
exec QBO_STATS_PKG.SET_DATE_RANGE('QBO_DATA', 'TXDETAILS_1', 'LAST_MODIFY_DATE', to_date('2014-01-01', 'yyyy-mm-dd'), trunc(sysdate+30));
set timing off

prompt === After fixing stats ===
@show_tx_col_stats

prompt === Locking stats ===

exec DBMS_STATS.LOCK_TABLE_STATS('QBO_DATA', 'TXHEADERS_1');
exec DBMS_STATS.LOCK_TABLE_STATS('QBO_DATA', 'TXDETAILS_1');

SELECT table_name, stattype_locked
FROM dba_tab_statistics 
WHERE owner = 'QBO_DATA'
and table_name IN ('TXHEADERS_1', 'TXDETAILS_1') 
and partition_name is null;

-- Rollback

-- PROMPT === Rollback ===

-- exec DBMS_STATS.UNLOCK_TABLE_STATS('QBO_DATA', 'TXHEADERS_1');
-- exec DBMS_STATS.UNLOCK_TABLE_STATS('QBO_DATA', 'TXDETAILS_1');

-- exec DBMS_STATS.RESTORE_TABLE_STATS('QBO_DATA', 'TXHEADERS_1', systimestamp - 7);
-- exec DBMS_STATS.RESTORE_TABLE_STATS('QBO_DATA', 'TXDETAILS_1', systimestamp - 7);

-- exec DBMS_STATS.LOCK_TABLE_STATS('QBO_DATA', 'TXHEADERS_1');
-- exec DBMS_STATS.LOCK_TABLE_STATS('QBO_DATA', 'TXDETAILS_1');

-- @show_tx_col_stats





