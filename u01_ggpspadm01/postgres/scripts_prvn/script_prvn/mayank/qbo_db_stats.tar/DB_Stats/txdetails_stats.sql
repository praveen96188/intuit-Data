
--spool txdetails_stats.log

col spoolname new_value spoolname
select 'txdetails_stats_'||SYS_CONTEXT('USERENV', 'DB_NAME')||'_'||to_char(sysdate,'YYMONDD_HH24.MI.SS') spoolname from dual;
spool '&spoolname' 

set lines 300 pages 999 trimspool on
col db_name format a12
col table_name format a40
col column_name format a40
col data_type format a10
col data_type format a12
col low_value format a40
col high_value format a40
col density format 99.999999
col low_value format a20
col high_value format a20
col method_opt_pref format a100
alter session set nls_date_format = 'yyyy-mm-dd hh24:mi:ss';

PROMPT === Before change ===

break on table_name dup skip 1

select c.table_name, c.column_name, c.data_type, c.num_distinct,  c.num_nulls, round(c.num_nulls/t.num_rows,2)*100 as pct_null, c.density, c.sample_size, c.last_analyzed, c.histogram, c.num_buckets,
decode(data_type,
                'VARCHAR2',to_char(raw_to_varchar2(low_value)),
                'DATE',to_char(raw_to_date(low_value), 'yyyy-mm-dd'),
                'NUMBER',to_char(raw_to_num(low_value))
        ) low_value,
        decode(data_type,
                'VARCHAR2',to_char(raw_to_varchar2(high_value)),
                'DATE',to_char(raw_to_date(high_value), 'yyyy-mm-dd'),
                'NUMBER',to_char(raw_to_num(high_value))
        ) high_value
from dba_tab_columns c, dba_tables t
where c.owner = t.owner
  and c.table_name = t.table_name
  and c.owner = 'QBO_DATA'
  and t.table_name IN ( 'TXHEADERS_1', 'TXDETAILS_1')
  and c.column_name IN ('COMPANY_ID', 'TX_DATE', 'INVOICE_ID', 'DEPOSIT_ID')
order by c.table_name desc, c.column_id;
  
  
select table_name, dbms_stats.get_prefs(ownname=>'QBO_DATA',tabname=>t.table_name,pname=>'METHOD_OPT') method_opt_pref
from dba_tables t
where t.owner = 'QBO_DATA'
and t.table_name IN ( 'TXHEADERS_1', 'TXDETAILS_1');


-- force histogram on invoice_id to get around extreme nulls case. bucket size 10 is arbitrary any number > 1 works

exec DBMS_STATS.SET_TABLE_PREFS ('QBO_DATA', 'TXDETAILS_1', 'METHOD_OPT', 'for all columns size auto for columns size 1 tx_date for columns size 10 deposit_id invoice_id');

set timing on
execute dbms_stats.gather_table_stats('QBO_DATA','TXDETAILS_1', degree=>2);
set timing off

-- need to reset dates after stats collection

exec QBO_STATS_PKG.SET_TX_DATE(to_date('2014-01-01', 'yyyy-mm-dd'), trunc(sysdate+90));

PROMPT === After change ===


select c.table_name, c.column_name, c.data_type, c.num_distinct,  c.num_nulls, round(c.num_nulls/t.num_rows,2)*100 as pct_null, c.density, c.sample_size, c.last_analyzed, c.histogram, c.num_buckets,
decode(data_type,
                'VARCHAR2',to_char(raw_to_varchar2(low_value)),
                'DATE',to_char(raw_to_date(low_value), 'yyyy-mm-dd'),
                'NUMBER',to_char(raw_to_num(low_value))
        ) low_value,
        decode(data_type,
                'VARCHAR2',to_char(raw_to_varchar2(high_value)),
                'DATE',to_char(raw_to_date(high_value), 'yyyy-mm-dd'),
                'NUMBER',to_char(raw_to_num(high_value))
        ) high_value
from dba_tab_columns c, dba_tables t
where c.owner = t.owner
  and c.table_name = t.table_name
  and c.owner = 'QBO_DATA'
  and t.table_name IN ( 'TXHEADERS_1', 'TXDETAILS_1')
  and c.column_name IN ('COMPANY_ID', 'TX_DATE', 'INVOICE_ID', 'DEPOSIT_ID')
order by c.table_name desc, c.column_id;

select table_name, dbms_stats.get_prefs(ownname=>'QBO_DATA',tabname=>t.table_name,pname=>'METHOD_OPT') method_opt_pref
from dba_tables t
where t.owner = 'QBO_DATA'
and t.table_name IN ( 'TXHEADERS_1', 'TXDETAILS_1');

spool off


/*
-- ==== Rollback ====

exec DBMS_STATS.SET_TABLE_PREFS ('QBO_DATA', 'TXDETAILS_1', 'METHOD_OPT', 'for all columns size auto');

set timing on
execute dbms_stats.gather_table_stats('QBO_DATA','TXDETAILS_1', degree=>2);
set timing off

*/
