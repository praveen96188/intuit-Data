
1. Disable partition level stats

- run @disable_partition_stats.sql

2. Fix tx table prefs, high/low values for dates etc.

- run @fix_tx_table_stats.sql

3. Lock stats on additional tables

- run @lock_table_stats_set2.sql


