set lines 300 pages 999 trimspool on
col db_name format a12
col table_name format a40
col column_name format a49
col low_value format a40
col high_value format a40
alter session set nls_date_format = 'yyyy-mm-dd hh24:mi:ss';

PROMPT === Before change ===
select SYS_CONTEXT('USERENV', 'DB_NAME') db_name, c.table_name, c.column_name, t.num_rows, c.num_distinct,  c.num_nulls, round(c.num_nulls/t.num_rows,2)*100 as pct_null, c.sample_size, c.histogram, c.num_buckets, c.last_analyzed
from dba_tab_columns c, dba_tables t
where c.owner = t.owner
  and c.table_name = t.table_name
  and c.owner = 'QBO_DATA'
  and c.table_name = 'TXHEADERS_1'
  and c.column_name IN ('COMPANY_ID', 'INVOICE_ID')
  order by column_name;
  
-- force histogram on invoice_id to get around extreme nulls case. bucket size 10 is arbitrary any number > 1 works

exec DBMS_STATS.SET_TABLE_PREFS ('QBO_DATA', 'TXHEADERS_1', 'METHOD_OPT', 'for columns invoice_id size 10');

execute dbms_stats.gather_table_stats('QBO_DATA','TXHEADERS_1');

PROMPT === After change ===

select SYS_CONTEXT('USERENV', 'DB_NAME') db_name, c.table_name, c.column_name, t.num_rows, c.num_distinct,  c.num_nulls, round(c.num_nulls/t.num_rows,2)*100 as pct_null, c.sample_size, c.histogram, c.num_buckets, c.last_analyzed
from dba_tab_columns c, dba_tables t
where c.owner = t.owner
  and c.table_name = t.table_name
  and c.owner = 'QBO_DATA'
  and c.table_name = 'TXHEADERS_1'
  and c.column_name IN ('COMPANY_ID', 'INVOICE_ID')
  order by column_name;
