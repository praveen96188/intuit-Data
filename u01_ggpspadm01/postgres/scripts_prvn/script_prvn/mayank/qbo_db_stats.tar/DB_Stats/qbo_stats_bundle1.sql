

PROMPT === Disable partition level stats ===

@disable_partition_stats.sql

PROMPT === Fix tx table prefs, high/low values for dates etc. ===

@fix_tx_table_stats.sql

PROMPT === Lock stats on additional tables ===

@lock_table_stats_set2.sql


