
spool fix_tx_date_stats.log

prompt === Before fixing stats ===
@show_tx_date_stats

prompt === Fixing stats for tx_date ====

set serveroutput on timing on 
exec QBO_STATS_PKG.SET_TX_DATE(to_date('2014-01-01', 'yyyy-mm-dd'), trunc(sysdate+90));
set timing off

prompt === After fixing stats ===
@show_tx_date_stats

spool off

