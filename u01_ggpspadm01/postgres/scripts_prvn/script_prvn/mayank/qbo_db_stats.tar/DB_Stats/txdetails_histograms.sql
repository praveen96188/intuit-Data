col spoolname new_value spoolname
select 'txdetails_histograms_'||SYS_CONTEXT('USERENV', 'DB_NAME')||'_'||to_char(sysdate,'YYMONDD_HH24.MI.SS') spoolname from dual;
spool '&spoolname' 

set lines 300 pages 999 trimspool on
col db_name format a12
col table_name format a40
col column_name format a49
col low_value format a40
col high_value format a40
col method_opt_pref format a100
alter session set nls_date_format = 'yyyy-mm-dd hh24:mi:ss';

PROMPT === Before change ===

select SYS_CONTEXT('USERENV', 'DB_NAME') db_name, c.table_name, c.column_name, t.num_rows, c.num_distinct,  c.num_nulls, round(c.num_nulls/t.num_rows,2)*100 as pct_null, c.sample_size, c.histogram, c.num_buckets, c.last_analyzed, t.last_analyzed
from dba_tab_columns c, dba_tables t
where c.owner = t.owner
  and c.table_name = t.table_name
  and c.owner = 'QBO_DATA'
  and c.table_name = 'TXDETAILS_1'
  and c.column_name IN ('COMPANY_ID', 'DEPOSIT_ID', 'INVOICE_ID')
  order by column_name;
  
  
select table_name, dbms_stats.get_prefs(ownname=>'QBO_DATA',tabname=>t.table_name,pname=>'METHOD_OPT') method_opt_pref
from dba_tables t
where t.owner = 'QBO_DATA'
and t.table_name IN ( 'TXHEADERS_1', 'TXDETAILS_1');


-- force histogram on invoice_id to get around extreme nulls case. bucket size 10 is arbitrary any number > 1 works

exec DBMS_STATS.SET_TABLE_PREFS ('QBO_DATA', 'TXDETAILS_1', 'METHOD_OPT', 'for all columns size auto for columns size 10 deposit_id invoice_id');

set timing on
execute dbms_stats.gather_table_stats('QBO_DATA','TXDETAILS_1');

PROMPT === After change ===

select SYS_CONTEXT('USERENV', 'DB_NAME') db_name, c.table_name, c.column_name, t.num_rows, c.num_distinct,  c.num_nulls, round(c.num_nulls/t.num_rows,2)*100 as pct_null, c.sample_size, c.histogram, c.num_buckets, c.last_analyzed
from dba_tab_columns c, dba_tables t
where c.owner = t.owner
  and c.table_name = t.table_name
  and c.owner = 'QBO_DATA'
  and c.table_name = 'TXDETAILS_1'
  and c.column_name IN ('COMPANY_ID', 'DEPOSIT_ID', 'INVOICE_ID')
  order by column_name;


PROMPT === Locking stats ===

exec DBMS_STATS.LOCK_TABLE_STATS('QBO_DATA', 'TXHEADERS_1');
exec DBMS_STATS.LOCK_TABLE_STATS('QBO_DATA', 'TXDETAILS_1');


SELECT table_name, stattype_locked
FROM dba_tab_statistics 
WHERE owner = 'QBO_DATA'
and table_name IN ('TXHEADERS_1', 'TXDETAILS_1') 
and partition_name is null;

spool off

