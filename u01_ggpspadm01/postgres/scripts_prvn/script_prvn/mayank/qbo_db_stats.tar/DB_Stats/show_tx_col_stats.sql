
set serveroutput on size unlimited
set lines 400 pages 999 trimspool on
col db_name format a12
col table_name format a40
col column_name format a49
col data_type format a12
col low_value format a40
col high_value format a40
col density format 99.999999
col low_value format a20
col high_value format a20
col method_opt_pref format a100
alter session set nls_date_format = 'yyyy-mm-dd hh24:mi:ss';

break on table_name dup skip 1

select c.table_name, c.column_name, c.data_type, c.num_distinct,  c.num_nulls, round(c.num_nulls/t.num_rows,2)*100 as pct_null, c.density, c.sample_size, t.last_analyzed, c.histogram, c.num_buckets,
decode(data_type,
                'VARCHAR2',to_char(raw_to_varchar2(low_value)),
                'DATE',to_char(raw_to_date(low_value), 'yyyy-mm-dd'),
                'NUMBER',to_char(raw_to_num(low_value))
        ) low_value,
        decode(data_type,
                'VARCHAR2',to_char(raw_to_varchar2(high_value)),
                'DATE',to_char(raw_to_date(high_value), 'yyyy-mm-dd'),
                'NUMBER',to_char(raw_to_num(high_value))
        ) high_value
from dba_tab_columns c, dba_tables t
where c.owner = t.owner
  and c.table_name = t.table_name
  and c.owner = 'QBO_DATA'
  and t.table_name IN ( 'TXHEADERS_1', 'TXDETAILS_1')
  and c.column_name IN ('COMPANY_ID', 'TX_DATE', 'INVOICE_ID', 'DEPOSIT_ID', 'LAST_MODIFY_DATE')
order by c.table_name desc, c.column_id;

select table_name, dbms_stats.get_prefs(ownname=>'QBO_DATA',tabname=>t.table_name,pname=>'METHOD_OPT') method_opt_pref
from dba_tables t
where t.owner = 'QBO_DATA'
and t.table_name IN ( 'TXHEADERS_1', 'TXDETAILS_1');

select SYS_CONTEXT('USERENV', 'DB_NAME') db_name, (
  select count(*) 
  from dba_indexes
  where table_owner = 'QBO_DATA'
  and index_name IN (
  upper('IDX_TimeActivities_CreateUser'),
  upper('IDX_TimeActivities_ModifyUser'),
  upper('IDX_TxMemorizedDetails_Creatsr'),
  upper('IDX_TxMemorizedDetails_Modfysr'),
  upper('IDX_TxMemorizedHeaders_Creatsr'),
  upper('IDX_TxMemorizedHeaders_Modfysr'),
  upper('IDX_RecurInfo_CreateUser'),
  upper('IDX_RecurInfo_ModifyUser'),
  upper('IDX_Terms_CreateUser'),
  upper('IDX_Terms_ModifyUser'),
  upper('IDX_Statements_CreateUser'),
  upper('IDX_Statements_ModifyUser'),
  upper('IDX_Items_CreateUser'),
  upper('IDX_Items_ModifyUser'),
  upper('IDX_Depts_CreateUser'),
  upper('IDX_Depts_ModifyUser'),
  upper('IDX_Klasses_CreateUser'),
  upper('IDX_Klasses_ModifyUser'),
  upper('IDX_PaymentMethods_CreateUser'),
  upper('IDX_PaymentMethods_ModifyUser'),
  upper('IDX_Employees_CreateUser'),
  upper('IDX_Employees_ModifyUser'),
  upper('IDX_Vendors_CreateUser'),
  upper('IDX_Vendors_ModifyUser'),
  upper('IDX_Customers_CreateUser'),
  upper('IDX_Customers_ModifyUser'),
  upper('IDX_Contacts_CreateUser'),
  upper('IDX_Contacts_ModifyUser'),
  upper('IDX_Accounts_CreateUser'),
  upper('IDX_Accounts_ModifyUser'),
  upper('IDX_BookkeepingActivity_Cretsr'),
  upper('IDX_BookkeepingActivity_Mdfysr'))
) as num_index,
(
  select count(*)
  from dba_constraints
  where owner='QBO_DATA' 
  and constraint_name IN (
  upper('BookkeepingActivity_CreateUser'),
  upper('BookkeepingActivity_ModifyUser'),
  upper('Accounts_CreateUser'),
  upper('Accounts_ModifyUser'),
  upper('Contacts_CreateUser'),
  upper('Contacts_ModifyUser'),
  upper('Customers_CreateUser'),
  upper('Customers_ModifyUser'),
  upper('Vendors_CreateUser'),
  upper('Vendors_ModifyUser'),
  upper('Employees_CreateUser'),
  upper('Employees_ModifyUser'),
  upper('PaymentMethods_CreateUser'),
  upper('PaymentMethods_ModifyUser'),
  upper('Klasses_CreateUser'),
  upper('Klasses_ModifyUser'),
  upper('Depts_CreateUser'),
  upper('Depts_ModifyUser'),
  upper('Items_CreateUser'),
  upper('Items_ModifyUser'),
  upper('Statements_CreateUser'),
  upper('Statements_ModifyUser'),
  upper('Terms_CreateUser'),
  upper('Terms_ModifyUser'),
  upper('RecurInfo_CreateUser'),
  upper('RecurInfo_ModifyUser'),
  upper('TxMemorizedHeaders_CreateUser'),
  upper('TxMemorizedHeaders_ModifyUser'),
  upper('TxMemorizedDetails_CreateUser'),
  upper('TxMemorizedDetails_ModifyUser'),
  upper('TimeActivities_CreateUser'),
  upper('TimeActivities_ModifyUser'))
) as num_constraints
from dual;