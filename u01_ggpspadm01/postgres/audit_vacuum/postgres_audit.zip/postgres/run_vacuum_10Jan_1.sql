\timing
set search_path to ibobadm;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m092014_from_psp;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m092014_from_as400 
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m092014_from_cris;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m092014_from_dflt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m092014_from_ews;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m042018_from_cris;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m042018_from_dflt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m042018_from_as400 
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m042018_from_ews;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m042018_from_psp;
SELECT pg_sleep(60);
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m042018_from_null;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m112014_from_psp;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m112014_from_null;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m112014_from_ews;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m042018_from_qbdt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m112014_from_qbdt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m112014_from_dflt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m112014_from_cris;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m112014_from_as400 
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m122014_from_as400
SELECT pg_sleep(60); 
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m122014_from_psp;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m122014_from_dflt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m122014_from_qbdt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m122014_from_cris;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m122014_from_null;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m122014_from_ews;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m052018_from_ews;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m052018_from_as400 
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m052018_from_cris;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m052018_from_dflt;
SELECT pg_sleep(60);
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m052018_from_psp;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m052018_from_null;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m052018_from_qbdt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m062018_from_as400 
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m062018_from_ews;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m062018_from_dflt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m062018_from_cris;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m062018_from_null;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m062018_from_psp;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m062018_from_qbdt;
SELECT pg_sleep(60);
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m072018_from_dflt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m072018_from_ews;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m072018_from_as400 
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m072018_from_cris;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m072018_from_qbdt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m072018_from_psp;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m072018_from_null;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m082018_from_as400 
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m082018_from_dflt;
vacuum (analyze, verbose) ibobadm.psp_source_system_transmission_m082018_from_ews;

