alter table pspadm.PSP_MONEY_MOVEMENT_TRANSACTION
split partition MONEY_MOVEMENT_TXN_9999 at (to_date('03/01/2024', 'MM/DD/YYYY'))
into
(partition MONEY_MOVEMENT_TXN_MG12024 tablespace PSP_LOB01,
 partition MONEY_MOVEMENT_TXN_9999  tablespace PSP_LOB01
 )
UPDATE INDEXES;

alter table pspadm.PSP_MONEY_MOVEMENT_TRANSACTION
split partition MONEY_MOVEMENT_TXN_9999 at (to_date('05/01/2024', 'MM/DD/YYYY'))
into
(partition MONEY_MOVEMENT_TXN_MG22024  tablespace PSP_LOB01,
 partition MONEY_MOVEMENT_TXN_9999  tablespace PSP_LOB01
 )
UPDATE INDEXES;

alter table pspadm.PSP_MONEY_MOVEMENT_TRANSACTION
split partition MONEY_MOVEMENT_TXN_9999 at (to_date('07/01/2024', 'MM/DD/YYYY'))
into
(partition MONEY_MOVEMENT_TXN_MG32024  tablespace PSP_LOB01,
 partition MONEY_MOVEMENT_TXN_9999  tablespace PSP_LOB01
 )
UPDATE INDEXES;

alter table pspadm.PSP_MONEY_MOVEMENT_TRANSACTION
split partition MONEY_MOVEMENT_TXN_9999 at (to_date('09/01/2024', 'MM/DD/YYYY'))
into
(partition MONEY_MOVEMENT_TXN_MG42024  tablespace PSP_LOB01,
 partition MONEY_MOVEMENT_TXN_9999  tablespace PSP_LOB01
 )
UPDATE INDEXES;

alter table pspadm.PSP_MONEY_MOVEMENT_TRANSACTION
split partition MONEY_MOVEMENT_TXN_9999 at (to_date('11/01/2024', 'MM/DD/YYYY'))
into
(partition MONEY_MOVEMENT_TXN_MG52024  tablespace PSP_LOB01,
 partition MONEY_MOVEMENT_TXN_9999  tablespace PSP_LOB01
 )
UPDATE INDEXES;

alter table pspadm.PSP_MONEY_MOVEMENT_TRANSACTION
split partition MONEY_MOVEMENT_TXN_9999 at (to_date('01/01/2025', 'MM/DD/YYYY'))
into
(partition MONEY_MOVEMENT_TXN_MG62024  tablespace PSP_LOB01,
 partition MONEY_MOVEMENT_TXN_9999  tablespace PSP_LOB01
 )
UPDATE INDEXES;

select segment_name, segment_type, partition_name, tablespace_name from dba_segments where owner = 'PSPADM' and segment_name = 'PSP_MONEY_MOVEMENT_TRANSACTION' and partition_name like 'MONEY_MOVEMENT_TXN_MG%2024' order by partition_name;
select table_name, partition_name, high_value, tablespace_name from dba_tab_partitions where table_owner = 'PSPADM' and table_name = 'PSP_MONEY_MOVEMENT_TRANSACTION' and partition_name like 'MONEY_MOVEMENT_TXN_MG%2024' order by partition_position;
select index_name, partition_name, high_value, tablespace_name, status from dba_ind_partitions where index_owner = 'PSPADM' and index_name in (select index_name from dba_indexes where owner = 'PSPADM' and table_name = 'PSP_MONEY_MOVEMENT_TRANSACTION') and partition_name like 'MONEY_MOVEMENT_TXN_MG%2024' order by partition_position, index_name;

select segment_name, segment_type, partition_name, tablespace_name from dba_segments where owner = 'PSPADM' and segment_name = 'PSP_MONEY_MOVEMENT_TRANSACTION' and partition_name like 'MONEY_MOVEMENT_TXN_MG%2011' order by partition_name;
select table_name, partition_name, high_value, tablespace_name from dba_tab_partitions where table_owner = 'PSPADM' and table_name = 'PSP_MONEY_MOVEMENT_TRANSACTION' and partition_name like 'MONEY_MOVEMENT_TXN_MG%2011' order by partition_position;
select index_name, partition_name, high_value, tablespace_name, status from dba_ind_partitions where index_owner = 'PSPADM' and index_name in (select index_name from dba_indexes where owner = 'PSPADM' and table_name = 'PSP_MONEY_MOVEMENT_TRANSACTION') and partition_name like 'MONEY_MOVEMENT_TXN_MG%2011' order by partition_position, index_name;

select segment_name, segment_type, partition_name, tablespace_name from dba_segments where owner = 'PSPADM' and segment_name = 'PSP_MONEY_MOVEMENT_TRANSACTION' and partition_name like 'MONEY_MOVEMENT_TXN_9999%' order by partition_name;
select table_name, partition_name, high_value, tablespace_name from dba_tab_partitions where table_owner = 'PSPADM' and table_name = 'PSP_MONEY_MOVEMENT_TRANSACTION' and partition_name = 'MONEY_MOVEMENT_TXN_9999' order by partition_position;
select index_name, partition_name, high_value, tablespace_name, status from dba_ind_partitions where index_owner = 'PSPADM' and index_name in (select index_name from dba_indexes where owner = 'PSPADM' and table_name = 'PSP_MONEY_MOVEMENT_TRANSACTION') and partition_name = 'MONEY_MOVEMENT_TXN_9999' order by partition_position, index_name;

select owner, object_name, object_type, status from dba_objects where object_name not like 'BIN%' and owner like 'PSP%' and status != 'VALID' order by 1,3,2;
