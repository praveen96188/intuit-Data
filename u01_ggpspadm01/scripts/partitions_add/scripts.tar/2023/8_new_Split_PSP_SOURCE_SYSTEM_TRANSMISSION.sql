--Partitions
CREATE TABLE ibobadm.psp_source_system_transmission_m012023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-01-01 00:00:00') TO ('2023-02-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m022023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-02-01 00:00:00') TO ('2023-03-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m032023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-03-01 00:00:00') TO ('2023-04-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m042023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-04-01 00:00:00') TO ('2023-05-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m052023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-05-01 00:00:00') TO ('2023-06-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m062023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-06-01 00:00:00') TO ('2023-07-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m072023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-07-01 00:00:00') TO ('2023-08-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m082023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-08-01 00:00:00') TO ('2023-09-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m092023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-09-01 00:00:00') TO ('2023-10-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m102023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-10-01 00:00:00') TO ('2023-11-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m112023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-11-01 00:00:00') TO ('2023-12-01 00:00:00')
    PARTITION BY LIST (from_source_system);

CREATE TABLE ibobadm.psp_source_system_transmission_m122023
        PARTITION OF ibobadm.psp_source_system_transmission
        FOR VALUES FROM ('2023-12-01 00:00:00') TO ('2024-01-01 00:00:00')
    PARTITION BY LIST (from_source_system);

--Subpartitions
CREATE TABLE ibobadm.psp_source_system_transmission_m012023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m012023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m012023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m012023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m012023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m012023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m012023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m012023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m012023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m012023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m012023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m012023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m012023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m012023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m022023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m022023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m022023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m022023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m022023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m022023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m022023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m022023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m022023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m022023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m022023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m022023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m022023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m022023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m032023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m032023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m032023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m032023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m032023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m032023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m032023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m032023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m032023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m032023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m032023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m032023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m032023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m032023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m042023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m042023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m042023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m042023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m042023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m042023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m042023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m042023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m042023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m042023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m042023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m042023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m042023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m042023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m052023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m052023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m052023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m052023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m052023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m052023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m052023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m052023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m052023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m052023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m052023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m052023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m052023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m052023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m062023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m062023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m062023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m062023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m062023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m062023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m062023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m062023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m062023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m062023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m062023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m062023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m062023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m062023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m072023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m072023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m072023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m072023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m072023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m072023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m072023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m072023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m072023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m072023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m072023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m072023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m072023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m072023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m082023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m082023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m082023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m082023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m082023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m082023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m082023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m082023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m082023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m082023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m082023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m082023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m082023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m082023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m092023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m092023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m092023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m092023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m092023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m092023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m092023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m092023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m092023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m092023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m092023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m092023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m092023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m092023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m102023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m102023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m102023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m102023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m102023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m102023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m102023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m102023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m102023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m102023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m102023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m102023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m102023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m102023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m112023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m112023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m112023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m112023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m112023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m112023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m112023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m112023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m112023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m112023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m112023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m112023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m112023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m112023
        FOR VALUES IN ('QBDT');

CREATE TABLE ibobadm.psp_source_system_transmission_m122023_from_as400
        PARTITION OF ibobadm.psp_source_system_transmission_m122023
        FOR VALUES IN ('AS400');

CREATE TABLE ibobadm.psp_source_system_transmission_m122023_from_cris
        PARTITION OF ibobadm.psp_source_system_transmission_m122023
        FOR VALUES IN ('CRIS');

CREATE TABLE ibobadm.psp_source_system_transmission_m122023_from_dflt
        PARTITION OF ibobadm.psp_source_system_transmission_m122023
        DEFAULT;

CREATE TABLE ibobadm.psp_source_system_transmission_m122023_from_ews
        PARTITION OF ibobadm.psp_source_system_transmission_m122023
        FOR VALUES IN ('EWS');

CREATE TABLE ibobadm.psp_source_system_transmission_m122023_from_null
        PARTITION OF ibobadm.psp_source_system_transmission_m122023
        FOR VALUES IN (NULL);

CREATE TABLE ibobadm.psp_source_system_transmission_m122023_from_psp
        PARTITION OF ibobadm.psp_source_system_transmission_m122023
        FOR VALUES IN ('PSP');

CREATE TABLE ibobadm.psp_source_system_transmission_m122023_from_qbdt
        PARTITION OF ibobadm.psp_source_system_transmission_m122023
        FOR VALUES IN ('QBDT');

