export PGPASSWORD="PIgRgK7d#(2XZ"
psql -h ppsp-stg-olap-new-cluster.cluster-cjls0bohfgpq.us-west-2.rds.amazonaws.com -U postgres -p 5432  -d pstgolap -f $1
