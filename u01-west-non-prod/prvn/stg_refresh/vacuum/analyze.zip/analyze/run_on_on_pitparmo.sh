export PGPASSWORD="l4rauo95N3V9VMHZqrdG-U_suu_OV-u4"
psql -h ppsp-stg-pitparmo.cluster-cjls0bohfgpq.us-west-2.rds.amazonaws.com -U postgres -p 5432 -d pitparmo -f $1
