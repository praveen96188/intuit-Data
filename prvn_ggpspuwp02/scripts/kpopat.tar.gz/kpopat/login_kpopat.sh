sqlplus kpopat@qbopp034
