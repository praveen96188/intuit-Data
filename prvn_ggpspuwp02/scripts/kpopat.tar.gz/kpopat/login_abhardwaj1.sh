sqlplus intuadmin@qbopp034
