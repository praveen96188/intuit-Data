;(function() {
  // eslint-disable-next-line no-undef
  const map = {
  "commitId": "204ba3a0e06c872c5266135cfd0d34b035840d11",
  "branchName": "release",
  "buildTime": "2026-03-25 20:29:27 GMT",
  "buildVersion": "5.1.11180",
  "css": [
    "ai-adoption/css/chunk-vendors.616096ac.css",
    "ai-adoption/css/app.44f40b9f.css"
  ],
  "js": [
    "ai-adoption/js/chunk-vendors.5dc4c15b.js",
    "ai-adoption/js/app.c5e21562.js"
  ],
  "key": "aiAdoptionResource"
};
  const prefix = 'https://static-cf.zoomdev.us/fe-static/';
  map.css && map.css.forEach(function(cssItem) {
    const linkTag = document.createElement('link');
    const cssURL = prefix + cssItem;
    linkTag.href = cssURL;
    linkTag.setAttribute('rel', 'stylesheet');
    document.head.appendChild(linkTag);
  });
  map.js && map.js.forEach(function(jsItem) {
    const scriptTag = document.createElement('script');
    const jsURL = prefix + jsItem;
    scriptTag.setAttribute('src', jsURL);
    document.body.appendChild(scriptTag);
  });
  window.domainFromServer = 'https://static-cf.zoomdev.us/fe-static/';
})();
